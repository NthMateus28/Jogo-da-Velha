package com.mateus.myjogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnComoJogar, btnJogar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnComoJogar = findViewById(R.id.btnComoJogar);
        btnJogar = findViewById(R.id.btnJogar);

        btnComoJogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  abrirComoJogar();
            }
        });

        btnJogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  abrirJogar();
            }
        });
    }
    private void abrirJogar () {
        Intent JanelaJogo = new Intent(this, Jogo.class);
        startActivity(JanelaJogo);
    }

    private void abrirComoJogar() {
        Intent JanelaComojogar = new Intent(this, ComoJogar.class);
        startActivity(JanelaComojogar);
    }
}